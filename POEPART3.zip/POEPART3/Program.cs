﻿using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Diagnostics.EntityFrameworkCore;
using POEPART3.Data;
using POEPART3.Models;

var builder = WebApplication.CreateBuilder(args);

// --------------------------------------------------------
// SQLite Database Setup
// --------------------------------------------------------
builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseSqlite(builder.Configuration.GetConnectionString("DefaultConnection")));

builder.Services.AddDatabaseDeveloperPageExceptionFilter();

// MVC + Sessions
builder.Services.AddControllersWithViews();
builder.Services.AddSession();
builder.Services.AddHttpContextAccessor();

var app = builder.Build();

// --------------------------------------------------------
// SEED USERS + SEED LECTURERS
// --------------------------------------------------------
using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();

    // 💥 FIXED — DO NOT USE Migrate() BECAUSE IT RE-CREATES DB EVERY RUN
    db.Database.EnsureCreated();

    // ------------------------------
    // SEED USERS
    // ------------------------------
    if (!db.Users.Any())
    {
        db.Users.AddRange(
            new User { Username = "lecturer1", Password = "123", Role = "Lecturer" },
            new User { Username = "coordinator1", Password = "123", Role = "Coordinator" },
            new User { Username = "manager1", Password = "123", Role = "Manager" },
            new User { Username = "hr1", Password = "123", Role = "HR" }
        );
        db.SaveChanges();
    }

    // ------------------------------
    // SEED DEFAULT LECTURERS
    // ------------------------------
    if (!db.Lecturers.Any())
    {
        db.Lecturers.AddRange(
            new Lecturer { LecturerId = 1, FirstName = "John", LastName = "Mokoena", Email = "john.mokoena@example.com", HourlyRate = 150 },
            new Lecturer { LecturerId = 2, FirstName = "Sarah", LastName = "Daniels", Email = "sarah.daniels@example.com", HourlyRate = 180 },
            new Lecturer { LecturerId = 3, FirstName = "Michael", LastName = "Smith", Email = "michael.smith@example.com", HourlyRate = 200 },
            new Lecturer { LecturerId = 4, FirstName = "Thabo", LastName = "Nkosi", Email = "thabo.nkosi@example.com", HourlyRate = 160 },
            new Lecturer { LecturerId = 5, FirstName = "Emily", LastName = "Clark", Email = "emily.clark@example.com", HourlyRate = 170 },
            new Lecturer { LecturerId = 6, FirstName = "Sipho", LastName = "Zulu", Email = "sipho.zulu@example.com", HourlyRate = 155 },
            new Lecturer { LecturerId = 7, FirstName = "Megan", LastName = "Naidoo", Email = "megan.naidoo@example.com", HourlyRate = 165 },
            new Lecturer { LecturerId = 8, FirstName = "David", LastName = "Johnson", Email = "david.johnson@example.com", HourlyRate = 175 },
            new Lecturer { LecturerId = 9, FirstName = "Ahmed", LastName = "Khan", Email = "ahmed.khan@example.com", HourlyRate = 160 },
            new Lecturer { LecturerId = 10, FirstName = "Jessica", LastName = "Pillay", Email = "jessica.pillay@example.com", HourlyRate = 190 },
            new Lecturer { LecturerId = 11, FirstName = "Carlos", LastName = "Ramirez", Email = "carlos.ramirez@example.com", HourlyRate = 185 },
            new Lecturer { LecturerId = 12, FirstName = "Lerato", LastName = "Mabaso", Email = "lerato.mabaso@example.com", HourlyRate = 175 }
        );
        db.SaveChanges();
    }
}

// --------------------------------------------------------
// MIDDLEWARE PIPELINE
// --------------------------------------------------------
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}
else
{
    app.UseDeveloperExceptionPage();
}

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();
app.UseSession();
app.UseAuthorization();

// --------------------------------------------------------
// DEFAULT ROUTE
// --------------------------------------------------------
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
