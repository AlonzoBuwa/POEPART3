﻿using System.ComponentModel.DataAnnotations;

namespace POEPART3.ViewModels
{
    public class ClaimCreateViewModel
    {
        [Required(ErrorMessage = "Lecturer ID is required.")]
        [Range(1, int.MaxValue, ErrorMessage = "Enter a valid numeric ID.")]
        public int LecturerId { get; set; }

        // Auto-filled from database - NOT required for validation
        public string? LecturerFirstName { get; set; }
        public string? LecturerLastName { get; set; }
        public decimal HourlyRate { get; set; }

        [Required(ErrorMessage = "Hours Worked is required.")]
        [Range(1, 180, ErrorMessage = "Hours must be between 1 and 180.")]
        public decimal HoursWorked { get; set; }

        public string? Notes { get; set; }

        //  FIX 1: Make document OPTIONAL (your controller already validates it)
        public IFormFile? SupportingDocument { get; set; }
    }
}
