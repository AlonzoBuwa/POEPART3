﻿namespace POEPART3.Models
{
    public class SupportingDocument
    {
        public int SupportingDocumentId { get; set; }

        public int ClaimId { get; set; }
        public Claim? Claim { get; set; }

        public string FileName { get; set; } = string.Empty;
        public string FilePath { get; set; } = string.Empty;

        public DateTime UploadDate { get; set; } = DateTime.Now;
    }
}
