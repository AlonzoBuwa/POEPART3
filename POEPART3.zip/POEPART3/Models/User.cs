﻿namespace POEPART3.Models
{
    public class User
    {
        public int UserId { get; set; }

        public required string Username { get; set; }
        public string Password { get; set; }

        // Roles can be: Lecturer, Coordinator, Manager, HR
        public required string Role { get; set; }
    }
}
