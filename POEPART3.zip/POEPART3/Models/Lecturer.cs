﻿using System.Security.Claims;

namespace POEPART3.Models
{
    public class Lecturer
    {
        public int LecturerId { get; set; }

        public string FirstName { get; set; } = string.Empty;
        public string LastName { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;

        public decimal HourlyRate { get; set; }

        public ICollection<Claim>? Claims { get; set; }
    }
}
