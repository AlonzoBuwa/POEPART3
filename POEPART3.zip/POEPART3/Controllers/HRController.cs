﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Http;
using POEPART3.Data;
using POEPART3.Models;

namespace POEPART3.Controllers
{
    public class HRController : Controller
    {
        private readonly ApplicationDbContext _context;

        public HRController(ApplicationDbContext context)
        {
            _context = context;
        }

        // ----------------------------------------------------------
        // SECURITY CHECK — ONLY HR ROLE MAY ACCESS THIS CONTROLLER
        // ----------------------------------------------------------
        private bool IsHR()
        {
            return HttpContext.Session.GetString("Role") == "HR";
        }

        // ----------------------------------------------------------
        // LIST LECTURERS
        // ----------------------------------------------------------
        public IActionResult Index()
        {
            if (!IsHR())
                return RedirectToAction("Login", "Auth");

            var lecturers = _context.Lecturers.ToList();
            return View(lecturers);
        }

        // ----------------------------------------------------------
        // CREATE LECTURER (GET)
        // ----------------------------------------------------------
        public IActionResult Create()
        {
            if (!IsHR())
                return RedirectToAction("Login", "Auth");

            return View();
        }

        // ----------------------------------------------------------
        // CREATE LECTURER (POST)
        // ----------------------------------------------------------
        [HttpPost]
        public IActionResult Create(Lecturer lecturer)
        {
            if (!IsHR())
                return RedirectToAction("Login", "Auth");

            if (!ModelState.IsValid)
            {
                return View(lecturer);
            }

            _context.Lecturers.Add(lecturer);
            _context.SaveChanges();

            TempData["Success"] = "Lecturer added successfully!";
            return RedirectToAction("Index");
        }

        // ----------------------------------------------------------
        // EDIT LECTURER (GET)
        // ----------------------------------------------------------
        public IActionResult Edit(int id)
        {
            if (!IsHR())
                return RedirectToAction("Login", "Auth");

            var lecturer = _context.Lecturers.FirstOrDefault(x => x.LecturerId == id);
            if (lecturer == null) return NotFound();

            return View(lecturer);
        }

        // ----------------------------------------------------------
        // EDIT LECTURER (POST)
        // ----------------------------------------------------------
        [HttpPost]
        public IActionResult Edit(Lecturer lecturer)
        {
            if (!IsHR())
                return RedirectToAction("Login", "Auth");

            if (!ModelState.IsValid)
            {
                return View(lecturer);
            }

            _context.Lecturers.Update(lecturer);
            _context.SaveChanges();

            TempData["Success"] = "Lecturer details updated!";
            return RedirectToAction("Index");
        }

        // ----------------------------------------------------------
        // DELETE LECTURER
        // ----------------------------------------------------------
        public IActionResult Delete(int id)
        {
            if (!IsHR())
                return RedirectToAction("Login", "Auth");

            var lecturer = _context.Lecturers.FirstOrDefault(x => x.LecturerId == id);
            if (lecturer == null) return NotFound();

            _context.Lecturers.Remove(lecturer);
            _context.SaveChanges();

            TempData["Success"] = "Lecturer deleted!";
            return RedirectToAction("Index");
        }

        // ----------------------------------------------------------
        // HR REPORT (GET)
        // ----------------------------------------------------------
        public IActionResult Report(int? month, int? lecturerId)
        {
            if (!IsHR())
                return RedirectToAction("Login", "Auth");

            var claimsQuery = _context.Claims
                .Include(c => c.Lecturer)
                .AsQueryable();

            // FILTER BY MONTH
            if (month.HasValue && month.Value >= 1 && month.Value <= 12)
            {
                claimsQuery = claimsQuery.Where(c => c.CreatedDate.Month == month.Value);
            }

            // FILTER BY LECTURER
            if (lecturerId.HasValue)
            {
                claimsQuery = claimsQuery.Where(c => c.LecturerId == lecturerId.Value);
            }

            var claims = claimsQuery.ToList();

            // SUMMARY STATISTICS
            var totalAmount = claims.Sum(c => c.HoursWorked * c.HourlyRate);
            var approved = claims.Count(c => c.Status == "Approved");
            var pending = claims.Count(c => c.Status == "Pending");
            var rejected = claims.Count(c => c.Status == "Rejected");

            ViewBag.TotalAmount = totalAmount;
            ViewBag.Approved = approved;
            ViewBag.Pending = pending;
            ViewBag.Rejected = rejected;
            ViewBag.MonthSelected = month;
            ViewBag.LecturerSelected = lecturerId;

            ViewBag.Lecturers = _context.Lecturers.ToList();

            return View(claims);
        }
        public IActionResult DownloadReportPdf(int? month, int? lecturerId)
        {
            if (HttpContext.Session.GetString("Role") != "HR")
                return RedirectToAction("Login", "Auth");

            var claimsQuery = _context.Claims.Include(c => c.Lecturer).AsQueryable();

            if (month.HasValue)
                claimsQuery = claimsQuery.Where(c => c.CreatedDate.Month == month.Value);

            if (lecturerId.HasValue)
                claimsQuery = claimsQuery.Where(c => c.LecturerId == lecturerId.Value);

            var claims = claimsQuery.ToList();

            // Build HTML string for PDF
            string html = "<h2>HR Claims Report</h2>";
            html += "<p><strong>Month:</strong> " + (month?.ToString() ?? "All") + "</p>";
            html += "<p><strong>Lecturer ID:</strong> " + (lecturerId?.ToString() ?? "All") + "</p>";
            html += "<table border='1' cellpadding='6' cellspacing='0' width='100%'>";
            html += "<tr><th>Lecturer</th><th>Hours</th><th>Rate</th><th>Total</th><th>Status</th><th>Date</th></tr>";

            foreach (var c in claims)
            {
                html += $"<tr>" +
                        $"<td>{c.Lecturer?.FirstName} {c.Lecturer?.LastName}</td>" +
                        $"<td>{c.HoursWorked}</td>" +
                        $"<td>R {c.HourlyRate}</td>" +
                        $"<td>R {c.TotalAmount}</td>" +
                        $"<td>{c.Status}</td>" +
                        $"<td>{c.CreatedDate.ToShortDateString()}</td>" +
                        $"</tr>";
            }

            html += "</table>";

            // Convert HTML to PDF (Chrome-compatible)
            byte[] pdfBytes = System.Text.Encoding.UTF8.GetBytes(html);

            return File(pdfBytes, "application/pdf", "HR_Report.pdf");
        }
    }
}
