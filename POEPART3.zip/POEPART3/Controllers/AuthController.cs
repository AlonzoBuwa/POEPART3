﻿using Microsoft.AspNetCore.Mvc;
using POEPART3.Data;
using POEPART3.Models;

namespace POEPART3.Controllers
{
    public class AuthController : Controller
    {
        private readonly ApplicationDbContext _context;

        public AuthController(ApplicationDbContext context)
        {
            _context = context;
        }

        // ----------------------------------------------------
        // LOGIN PAGE (GET)
        // ----------------------------------------------------
        public IActionResult Login()
        {
            return View();
        }

        // ----------------------------------------------------
        // LOGIN SUBMIT (POST)
        // ----------------------------------------------------
        [HttpPost]
        public IActionResult Login(string username, string password)
        {
            var user = _context.Users
                .FirstOrDefault(u => u.Username == username && u.Password == password);

            if (user == null)
            {
                TempData["Error"] = "Invalid username or password.";
                return View();
            }

            // Save session
            HttpContext.Session.SetString("Username", user.Username);
            HttpContext.Session.SetString("Role", user.Role);

            // Redirect based on Role
            switch (user.Role)
            {
                case "Lecturer":
                    return RedirectToAction("MyClaims", "LecturerClaims");

                case "Coordinator":
                    return RedirectToAction("Pending", "AdminClaims");

                case "Manager":
                    return RedirectToAction("Pending", "AdminClaims");

                case "HR":
                    return RedirectToAction("Index", "HR");

                default:
                    return RedirectToAction("Login", "Auth");
            }
        }

        // ----------------------------------------------------
        // LOGOUT
        // ----------------------------------------------------
        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Login");
        }
    }
}
