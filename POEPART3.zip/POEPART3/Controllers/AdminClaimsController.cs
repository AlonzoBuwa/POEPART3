﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Http;
using POEPART3.Data;
using POEPART3.Models;

namespace POEPART3.Controllers
{
    public class AdminClaimsController : Controller
    {
        private readonly ApplicationDbContext _context;

        public AdminClaimsController(ApplicationDbContext context)
        {
            _context = context;
        }

        // ---------------------------------------------------
        // SECURITY CHECK (used by all admin actions)
        // ---------------------------------------------------
        private bool AdminAllowed()
        {
            var role = HttpContext.Session.GetString("Role");
            return role == "Coordinator" || role == "Manager";
        }

        // ---------------------------------------------------
        // VIEW PENDING CLAIMS
        // ---------------------------------------------------
        public IActionResult Pending()
        {
            if (!AdminAllowed())
                return RedirectToAction("Login", "Auth");

            var claims = _context.Claims
                .Include(c => c.Lecturer)
                .Include(c => c.Documents)
                .Where(c => c.Status == "Pending")
                .OrderByDescending(c => c.CreatedDate)
                .ToList();

            return View(claims);
        }

        // ---------------------------------------------------
        // APPROVE A CLAIM
        // ---------------------------------------------------
        public IActionResult Approve(int id)
        {
            if (!AdminAllowed())
                return RedirectToAction("Login", "Auth");

            var claim = _context.Claims.FirstOrDefault(c => c.ClaimId == id);

            if (claim == null)
                return NotFound();

            claim.Status = "Approved";
            _context.SaveChanges();

            TempData["Success"] = "Claim Approved Successfully";
            return RedirectToAction("Pending");
        }

        // ---------------------------------------------------
        // REJECT A CLAIM
        // ---------------------------------------------------
        public IActionResult Reject(int id)
        {
            if (!AdminAllowed())
                return RedirectToAction("Login", "Auth");

            var claim = _context.Claims.FirstOrDefault(c => c.ClaimId == id);

            if (claim == null)
                return NotFound();

            claim.Status = "Rejected";
            _context.SaveChanges();

            TempData["Success"] = "Claim Rejected";
            return RedirectToAction("Pending");
        }

        // ---------------------------------------------------
        // VIEW DOCUMENT
        // ---------------------------------------------------
        public IActionResult ViewDocument(int docId)
        {
            if (!AdminAllowed())
                return RedirectToAction("Login", "Auth");

            var doc = _context.SupportingDocuments.FirstOrDefault(d => d.SupportingDocumentId == docId);

            if (doc == null)
                return NotFound();

            return Redirect(doc.FilePath);
        }
    }
}
