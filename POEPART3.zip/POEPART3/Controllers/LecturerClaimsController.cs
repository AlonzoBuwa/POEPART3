﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using POEPART3.Data;
using POEPART3.Models;
using POEPART3.ViewModels;
using System.IO;
using Microsoft.AspNetCore.Http;

namespace POEPART3.Controllers
{
    public class LecturerClaimsController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly IWebHostEnvironment _env;

        public LecturerClaimsController(ApplicationDbContext context, IWebHostEnvironment env)
        {
            _context = context;
            _env = env;
        }

        // ======================================================
        // GET: Submit Claim Page (Lecturer Only)
        // ======================================================
        public IActionResult Create()
        {
            if (HttpContext.Session.GetString("Role") != "Lecturer")
                return RedirectToAction("Login", "Auth");

            return View(new ClaimCreateViewModel());
        }

        // ======================================================
        // AUTO-FILL LECTURER DETAILS (AJAX)
        // ======================================================
        [HttpGet]
        public JsonResult GetLecturerDetails(int id)
        {
            var lecturer = _context.Lecturers.FirstOrDefault(l => l.LecturerId == id);

            if (lecturer == null)
                return Json(new { exists = false });

            return Json(new
            {
                exists = true,
                firstName = lecturer.FirstName,
                lastName = lecturer.LastName,
                hourlyRate = lecturer.HourlyRate
            });
        }

        // ======================================================
        // POST: Submit New Claim (Lecturer Only)
        // ======================================================
        [HttpPost]
        public IActionResult Create(ClaimCreateViewModel model)
        {
            if (HttpContext.Session.GetString("Role") != "Lecturer")
                return RedirectToAction("Login", "Auth");

            if (!ModelState.IsValid)
                return View(model);

            // ============================================
            // VALIDATION: 180 hour monthly limit
            // ============================================
            var currentMonth = DateTime.Now.Month;

            // FIXED: SQLite decimal sum issue by forcing client-side SUM
            var hoursThisMonth = _context.Claims
                .Where(c => c.LecturerId == model.LecturerId &&
                            c.CreatedDate.Month == currentMonth)
                .ToList()   // forces SQLite to fetch rows first
                .Sum(c => c.HoursWorked);

            var newTotal = hoursThisMonth + model.HoursWorked;

            if (newTotal > 180)
            {
                ModelState.AddModelError("HoursWorked",
                    $"You cannot exceed 180 hours in a month. " +
                    $"Current: {hoursThisMonth} hrs, adding: {model.HoursWorked} hrs = {newTotal} hrs");

                return View(model);
            }

            // ============================================
            // AUTO-CREATE OR UPDATE LECTURER
            // ============================================
            var lecturer = _context.Lecturers
                .FirstOrDefault(l => l.LecturerId == model.LecturerId);

            // ============================================
            // AUTO-CREATE OR UPDATE LECTURER (Option A)
            // ============================================

            if (lecturer == null)
            {
                // VALIDATION: New lecturer requires first/last name and rate
                if (string.IsNullOrWhiteSpace(model.LecturerFirstName) ||
                    string.IsNullOrWhiteSpace(model.LecturerLastName) ||
                    model.HourlyRate <= 0)
                {
                    ModelState.AddModelError("",
                        "For new lecturers, please provide First Name, Last Name, and Hourly Rate.");
                    return View(model);
                }

                lecturer = new Lecturer
                {
                    LecturerId = model.LecturerId,
                    FirstName = model.LecturerFirstName,
                    LastName = model.LecturerLastName,
                    Email = $"{model.LecturerFirstName.ToLower()}@example.com",
                    HourlyRate = model.HourlyRate
                };

                _context.Lecturers.Add(lecturer);
            }
            else
            {
                // Existing lecturer – update details if needed
                lecturer.FirstName = model.LecturerFirstName ?? lecturer.FirstName;
                lecturer.LastName = model.LecturerLastName ?? lecturer.LastName;
                lecturer.HourlyRate = model.HourlyRate > 0 ? model.HourlyRate : lecturer.HourlyRate;
            }

            _context.SaveChanges();


            _context.SaveChanges();

            // ============================================
            // CREATE CLAIM
            // ============================================
            var claim = new Claim
            {
                LecturerId = model.LecturerId,
                HoursWorked = model.HoursWorked,
                HourlyRate = model.HourlyRate,
                TotalAmount = model.HoursWorked * model.HourlyRate,
                Notes = model.Notes,
                Status = "Pending",
                CreatedDate = DateTime.Now
            };

            _context.Claims.Add(claim);
            _context.SaveChanges();

            // ============================================
            // FILE UPLOAD HANDLING
            // ============================================
            if (model.SupportingDocument != null)
            {
                // size validation
                if (model.SupportingDocument.Length > 5 * 1024 * 1024)
                {
                    TempData["Error"] = "File too large. Max 5MB.";
                    return View(model);
                }

                // type validation
                var ext = Path.GetExtension(model.SupportingDocument.FileName).ToLower();
                var allowed = new[] { ".pdf", ".docx", ".xlsx" };

                if (!allowed.Contains(ext))
                {
                    TempData["Error"] = "Only PDF, DOCX, XLSX allowed.";
                    return View(model);
                }

                // ensure uploads folder exists
                var uploads = Path.Combine(_env.WebRootPath, "uploads");
                if (!Directory.Exists(uploads))
                    Directory.CreateDirectory(uploads);

                // save file
                var newFile = $"{Guid.NewGuid()}_{model.SupportingDocument.FileName}";
                var filePath = Path.Combine(uploads, newFile);

                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    model.SupportingDocument.CopyTo(stream);
                }

                // save document record
                var document = new SupportingDocument
                {
                    ClaimId = claim.ClaimId,
                    FileName = model.SupportingDocument.FileName,
                    FilePath = "/uploads/" + newFile,
                    UploadDate = DateTime.Now
                };

                _context.SupportingDocuments.Add(document);
                _context.SaveChanges();
            }

            TempData["Success"] = "Claim submitted successfully!";
            return RedirectToAction("MyClaims");
        }

        // ======================================================
        // VIEW MY CLAIMS (Lecturer Only)
        // ======================================================
        public IActionResult MyClaims()
        {
            if (HttpContext.Session.GetString("Role") != "Lecturer")
                return RedirectToAction("Login", "Auth");

            var claims = _context.Claims
                .Include(c => c.Lecturer)
                .Include(c => c.Documents)
                .OrderByDescending(c => c.CreatedDate)
                .ToList();

            return View(claims);
        }
    }
}
