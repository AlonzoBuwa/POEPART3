﻿using Microsoft.EntityFrameworkCore;
using POEPART3.Models;

namespace POEPART3.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options) { }

        public DbSet<Lecturer> Lecturers { get; set; }
        public DbSet<Claim> Claims { get; set; }
        public DbSet<SupportingDocument> SupportingDocuments { get; set; }

        // NEW: Users table for login system
        public DbSet<User> Users { get; set; }

        // NEW: Seeding default system users
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // SEED DEFAULT LOGIN ACCOUNTS
            modelBuilder.Entity<User>().HasData(
                new User { UserId = 1, Username = "lecturer1", Password = "123", Role = "Lecturer" },
                new User { UserId = 2, Username = "coordinator", Password = "123", Role = "Coordinator" },
                new User { UserId = 3, Username = "manager", Password = "123", Role = "Manager" },
                new User { UserId = 4, Username = "hr", Password = "123", Role = "HR" }
            );
        }
    }
}
